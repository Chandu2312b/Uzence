import React from 'react';
import ComponentDemo from './components/ComponentDemo';

function App() {
  return <ComponentDemo />;
}
// for assessment purposes only

export default App;